exports.handler = async (event) => {
    // TODO implement
    return await generateQrCode()   
}

function generateQrCode(){
    
}